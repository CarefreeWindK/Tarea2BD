Rails.application.routes.draw do
  root 'login#index'
  get 'login/index'

  get '/dashboard', to: 'articulos#index'

  get 'formulario', to: 'articulos#formulario'
  get 'application.css', to: 'application#css'
  post 'insertar', to: 'articulos#insertar'
  get '/formulario', to: 'articulos#nuevo'
  get '/articulo/idClaseArticuloToNombreClaseArticulo/:id', to: 'articulos#idClaseArticuloToNombreClaseArticulo'
  get '/manifest.js', to: 'articulos#manifest'
  post 'articulos/filtrarPorNombre', to: 'articulos#filtrarPorNombre'
  get 'articulos/filtrarPorNombre', to: 'articulos#filtrarPorNombre'
  post '/login', to: 'login#create'
  delete '/logout', to: 'login#destroy'

  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
