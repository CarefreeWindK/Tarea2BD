class ArticulosController < ApplicationController

  def index
  @resultados ||= Articulo.buscarArticulos
  # Verificar si se envió un nombre de usuario en el formulario de inicio de sesión
  @nombresClase= Articulo.buscarNombreClase

  # Asignar el valor de session[:username] a @username
  @username = session[:username]
  puts "El valor de session[:username] es: #{session[:username]}" # Imprime el valor de session[:username]
  # Renderizar la vista
  render "articulos/index"

  end
  def formulario
    @resultados = Articulo.buscarArticulos
    @nombresClase= Articulo.buscarNombreClase
    # procesar los resultados de la stored procedure y asignarlos a la vista
  end
  def css
    # Configura la respuesta para que sirva el archivo CSS
    send_file "#{Rails.root}/app/assets/stylesheets/application.css", type: 'text/css', disposition: 'inline'
  end
  protect_from_forgery except: [:manifest]
  def manifest
    send_file "#{Rails.root}/app/assets/config/manifest.js", type: 'text/javascript', disposition: 'inline'
  end
  def insertar
    username=session[:username].to_s
    puts ("me llamoi> "+username)
    ActiveRecord::Base.transaction do
      variable1 = params[:variable1] #nombre articulo
      variable2 = params[:variable2] # precio
      variable3 = params[:variable3] # clase articulo
      ip_address = Socket.ip_address_list.find { |addr| addr.ipv4? && !addr.ipv4_loopback? }.ip_address
      sql = "DECLARE @resultado INT; EXECUTE dbo.InsertarArticulo
      #{ActiveRecord::Base.connection.quote(variable3)}
      ,#{ActiveRecord::Base.connection.quote(variable1)}
      ,#{ActiveRecord::Base.connection.quote(variable2)}
      ,#{ActiveRecord::Base.connection.quote(username)}
      ,#{ActiveRecord::Base.connection.quote(ip_address)}
      , @resultado OUTPUT; SELECT @resultado AS resultado;"
      results = ActiveRecord::Base.connection.raw_connection.execute(sql)
      resultado = results.first['resultado'].to_i

      if resultado == 0
        puts "too bien"
        redirect_to formulario_path(allow_other_host: true), notice: 'Artículo insertado correctamente'
      else
        puts "too mal"
        puts resultado
        redirect_to '/login'
      end
    end
  end



  def nuevo
    # Aquí se puede agregar lógica para preparar los datos necesarios para el formulario
    render 'formulario' # Renderiza la vista 'nuevo.html.erb'
  end

  def idClaseArticuloToNombreClaseArticulo
    id = params[:id].to_i
    sql = "EXECUTE dbo.IdClaseArticuloToNombreClaseArticulo #{ActiveRecord::Base.connection.quote(id)}"
    palabra = ActiveRecord::Base.connection.select_value(sql)
    # Devuelve la palabra como cadena
    render plain: palabra.to_s
  end
  def NombreClaseArticuloToidCLaseArticulo
  end

  def filtrarPorNombre
    patron = params[:patron]
    results = Articulo.find_by_sql(["EXEC dbo.busquedaFiltradaPorNombre ?", patron])
    @resultados_filtrados = results
    if results.present?
      puts "holaaaa"
      @resultados_filtrados = results
      render "articulos/index"
    else
      @resultados_filtrados = []
      redirect_to '/dashboard'
    end
  end

end
