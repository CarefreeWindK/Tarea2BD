class Articulo < ActiveRecord::Base
    self.table_name = 'Articulo'
    def self.buscarArticulos
        self.table_name = 'Articulo'
        results = find_by_sql("EXEC dbo.buscarArticulos")
        if results.present?
            # procesar los resultados de la stored procedure
            return results
        else
            return []
        end
    end
    def self.buscarNombreClase
        self.table_name = 'ClaseArticulo'
        results = find_by_sql("EXEC dbo.retonarNombreClaseArticulo")
        if results.present?
            # procesar los resultados de la stored procedure
            return results
        else
            return []
        end
    end
end
