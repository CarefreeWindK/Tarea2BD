# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.0].define(version: 2023_02_21_000926) do
  create_table "Articulo", primary_key: "Id", id: :integer, force: :cascade do |t|
    t.integer "IdClaseArticulo"
    t.varchar "Nombre", limit: 128, null: false
    t.money "Precio", precision: 19, scale: 4, null: false
  end

  create_table "ClaseArticulo", primary_key: "Id", id: :integer, force: :cascade do |t|
    t.varchar "Nombre", limit: 64
  end

  create_table "DBErrors", primary_key: "ErrorId", id: :integer, force: :cascade do |t|
    t.varchar "UserName", limit: 128
    t.integer "ErrorNumber"
    t.integer "ErrorState"
    t.integer "ErrorSeverity"
    t.integer "ErrorLine"
    t.varchar_max "ErrorProcedure"
    t.varchar_max "ErrorMessage"
    t.datetime "ErrorDateTime", precision: nil
  end

  create_table "EventLog", primary_key: "Id", id: :integer, force: :cascade do |t|
    t.varchar "LogDescription", limit: 2048, null: false
    t.integer "PostIdUser", null: false
    t.varchar "PostIP", limit: 64, null: false
    t.datetime "PostTime", precision: nil, null: false
  end

  create_table "Usuario", primary_key: "Id", id: :integer, force: :cascade do |t|
    t.varchar "UserName", limit: 16, null: false
    t.varchar "pin", limit: 16, null: false
  end

  add_foreign_key "Articulo", "ClaseArticulo", column: "IdClaseArticulo", primary_key: "Id", name: "FK_Articulo_ClaseArticulo"
end
