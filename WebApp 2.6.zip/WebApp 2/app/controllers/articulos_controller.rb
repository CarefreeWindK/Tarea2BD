class ArticulosController < ApplicationController
  def index
  @resultados ||= Articulo.buscarArticulos
  # Verificar si se envió un nombre de usuario en el formulario de inicio de sesión
  @nombresClase= Articulo.buscarNombreClase

  # Asignar el valor de session[:username] a @username
  @username = session[:username]

  # Renderizar la vista
  render "articulos/index"

  end
  def formulario
    @resultados = Articulo.buscarArticulos
    @nombresClase= Articulo.buscarNombreClase
    # procesar los resultados de la stored procedure y asignarlos a la vista
  end
  def css
    # Configura la respuesta para que sirva el archivo CSS
    send_file "#{Rails.root}/app/assets/stylesheets/application.css", type: 'text/css', disposition: 'inline'
  end
  protect_from_forgery except: [:manifest]
  def manifest
    send_file "#{Rails.root}/app/assets/config/manifest.js", type: 'text/javascript', disposition: 'inline'
  end
  def insertar
    username=session[:username].to_s

    ActiveRecord::Base.transaction do
      variable1 = params[:variable1] #nombre articulo
      variable2 = params[:variable2] # precio
      variable3 = params[:variable3] # clase articulo
      ip_address = Socket.ip_address_list.find { |addr| addr.ipv4? && !addr.ipv4_loopback? }.ip_address
      sql = "DECLARE @resultado INT; EXECUTE dbo.InsertarArticulo
      #{ActiveRecord::Base.connection.quote(variable3)}
      ,#{ActiveRecord::Base.connection.quote(variable1)}
      ,#{ActiveRecord::Base.connection.quote(variable2)}
      ,#{ActiveRecord::Base.connection.quote(username)}
      ,#{ActiveRecord::Base.connection.quote(ip_address)}
      , @resultado OUTPUT; SELECT @resultado AS resultado;"
      results = ActiveRecord::Base.connection.raw_connection.execute(sql)
      resultado = results.first['resultado'].to_i

      if resultado == 0

        redirect_to formulario_path(allow_other_host: true), notice: 'Artículo insertado correctamente'
      else

        redirect_to '/login'
      end
    end
  end



  def nuevo
    # Aquí se puede agregar lógica para preparar los datos necesarios para el formulario
    render 'formulario' # Renderiza la vista 'nuevo.html.erb'
  end

  def idClaseArticuloToNombreClaseArticulo
    id = params[:id].to_i
    sql = "EXECUTE dbo.IdClaseArticuloToNombreClaseArticulo #{ActiveRecord::Base.connection.quote(id)}"
    palabra = ActiveRecord::Base.connection.select_value(sql)
    # Devuelve la palabra como cadena
    render plain: palabra.to_s
  end

  def filtrarPorNombre
    @nombresClase= Articulo.buscarNombreClase
    patron = params[:patron]
    results = Articulo.find_by_sql(["EXEC dbo.busquedaFiltradaPorNombre ?", patron])
    @resultados_filtrados = results
    @csrf_token = form_authenticity_token
    if results.present?
      @csrf_token = form_authenticity_token
      @resultados_filtrados = results
      render "articulos/index",:preserve => true # <-- Agrega :preserve => true
    else
      @resultados_filtrados = []
      session_data = session.to_hash # guarda los datos de sesión en un hash
      reset_session # reinicia la sesión
      session_data.each { |key, value| session[key.to_sym] = value }
      redirect_to '/dashboard'
    end
  end
  def filtrarPorCantidad
    @username = session[:username]
    @nombresClase= Articulo.buscarNombreClase
    patron = params[:patron]
    results = Articulo.find_by_sql(["EXEC dbo.busquedaFiltradaPorCantidad ?", patron])
    @resultados_filtrados = results
    @csrf_token = form_authenticity_token
    if results.present?
      @resultados_filtrados = results
      @csrf_token = form_authenticity_token
      render "articulos/index",:preserve => true # <-- Agrega :preserve => true
    else
      session_data = session.to_hash # guarda los datos de sesión en un hash
      reset_session # reinicia la sesión
      session_data.each { |key, value| session[key.to_sym] = value }
      @resultados_filtrados = []
      redirect_to '/dashboard'
    end
  end
  def filtrarPorClase
    @username = session[:username]
    @nombresClase= Articulo.buscarNombreClase
    patron = params[:patron]
    sql = "EXECUTE dbo.NombreClaseArticuloToIdClaseArticulo #{ActiveRecord::Base.connection.quote(patron)}"
    id = ActiveRecord::Base.connection.select_value(sql)
    results = Articulo.find_by_sql(["EXEC dbo.busquedaFiltradaPorClase ?", id.to_i])
    @resultados_filtrados = results
    @csrf_token = form_authenticity_token
    if results.present?
      @csrf_token = form_authenticity_token
      @resultados_filtrados = results
      render "articulos/index",:preserve => true # <-- Agrega :preserve => true
    else
      session_data = session.to_hash # guarda los datos de sesión en un hash
      reset_session # reinicia la sesión
      session_data.each { |key, value| session[key.to_sym] = value }
      @resultados_filtrados = []
      redirect_to '/dashboard'
    end
  end
end
