# frozen_string_literal: true

class LoginController < ApplicationController
  def index
    render "articulos/login"
  end

  def create
    variable1 = params[:username]
    variable2 = params[:password]
    ip_address = Socket.ip_address_list.find { |addr| addr.ipv4? && !addr.ipv4_loopback? }.ip_address
    sql = "DECLARE @resultado INT; EXEC dbo.validarUsuario #{ActiveRecord::Base.connection.quote(variable1)}, #{ActiveRecord::Base.connection.quote(variable2)},'#{ip_address}' , @resultado OUTPUT; SELECT @resultado AS resultado;"
    results = ActiveRecord::Base.connection.raw_connection.execute(sql)

    resultado = results.fields.first.to_i
    if resultado.is_a?(Numeric)
      puts "El resultado es un número"
      puts resultado
    else
      puts "El resultado no es un número"
      puts resultado
    end
    if resultado == 0
      puts "too bien"
      redirect_to '/dashboard'
    else
      puts "too mal"
      puts resultado
      redirect_to '/login'
    end

  end



  def destroy
    # Destruir la sesión del usuario
  end
end
