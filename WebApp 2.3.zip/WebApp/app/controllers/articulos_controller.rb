class ArticulosController < ApplicationController
  def index
    @resultados = Articulo.buscarArticulos
    render "articulos/index"
    # procesar los resultados de la stored procedure y asignarlos a la vista
  end
  def formulario
    @resultados = Articulo.buscarArticulos
    # procesar los resultados de la stored procedure y asignarlos a la vista
  end
  def css
    # Configura la respuesta para que sirva el archivo CSS
    send_file "#{Rails.root}/app/assets/stylesheets/application.css", type: 'text/css', disposition: 'inline'
  end
  protect_from_forgery except: [:manifest]
  def manifest
    send_file "#{Rails.root}/app/assets/config/manifest.js", type: 'text/javascript', disposition: 'inline'
  end
  def insertar # Método que se ejecuta cuando se envía el formulario
    variable1 = params[:variable1] # Recupera el valor del parámetro 'variable1'
    variable2 = params[:variable2] # Recupera el valor del parámetro 'variable2'
    sql = "EXECUTE dbo.insertarArticulo
    #{ActiveRecord::Base.connection.quote(variable1)}
    ,#{ActiveRecord::Base.connection.quote(variable2)}" # Construye la sentencia SQL
    ActiveRecord::Base.connection.execute(sql) # Ejecuta la sentencia SQL
    # Envía un mensaje a todas las pestañas abiertas
    redirect_to formulario_path(allow_other_host: true), notice: 'Artículo insertado correctamente'
  end

  def nuevo
    # Aquí se puede agregar lógica para preparar los datos necesarios para el formulario
    render 'formulario' # Renderiza la vista 'nuevo.html.erb'
  end

  def idClaseArticuloToNombreClaseArticulo
    id = params[:id].to_i
    sql = "EXECUTE dbo.IdClaseArticuloToNombreClaseArticulo #{ActiveRecord::Base.connection.quote(id)}"
    palabra = ActiveRecord::Base.connection.select_value(sql)
    # Devuelve la palabra como cadena
    render plain: palabra.to_s
  end
  def NombreClaseArticuloToidCLaseArticulo
  end

end
