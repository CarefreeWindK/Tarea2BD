Rails.application.config.session_store :cookie_store, key: :username

