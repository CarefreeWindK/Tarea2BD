//= link_tree ../images
//= link_directory ../stylesheets .css
//= link_tree ../../javascript .js
//= link_tree ../../../vendor/javascript .js
const cacheNombresClaseArticulo = {};


function insertar(){
    //funcion que abre otra pestana y permite ingresar articulos
    window.open('/formulario', 'MiVentana', 'width=500,height=223,resizable=0')
}
function cerrar() {
    //Funcion que cierra la webapp
    window.close();
}


async function obtenerNombreClaseArticuloAsync(idClaseArticulo) {
    if (cacheNombresClaseArticulo[idClaseArticulo]) {
        return cacheNombresClaseArticulo[idClaseArticulo];
    }

    try {
        const response = await fetch(`/articulo/idClaseArticuloToNombreClaseArticulo/${idClaseArticulo}`);
        const palabra = await response.text();
        cacheNombresClaseArticulo[idClaseArticulo] = palabra;
        return palabra;
    } catch (error) {
        console.error(`Error al obtener la palabra: ${error}`);
        // Hacer algo en caso de que se produzca un error, como mostrar un mensaje de error en la pantalla
        return "";
    }
}

async function actualizarNombresClaseArticulo() {
    console.log("Actualizando nombres de clase de artículo");
    // Obtener todos los elementos de grid-item que contienen el ID de la clase de artículo
    const elementosClaseArticulo = document.getElementsByClassName("nombreClaseArticulo");

    // Almacenar los nombres de las clases de artículos ya obtenidos
    const nombresClaseArticuloObtenidos = {};

    // Para cada elemento, obtener su ID de clase de artículo y actualizar el valor de la etiqueta correspondiente
    for (let i = 0; i < elementosClaseArticulo.length; i++) {
        const idClaseArticulo = elementosClaseArticulo[i].getAttribute("data-clase");

        // Verificar si el nombre de la clase de artículo ya está en caché
        if (nombresClaseArticuloObtenidos[idClaseArticulo]) {
            const nombreClaseArticulo = nombresClaseArticuloObtenidos[idClaseArticulo];
            const elementoNombreClaseArticulo = elementosClaseArticulo[i];
            elementoNombreClaseArticulo.textContent = nombreClaseArticulo;
        } else {
            // Si el nombre de la clase de artículo no está en caché, hacer una llamada a obtenerNombreClaseArticuloAsync
            const nombreClaseArticulo = await obtenerNombreClaseArticuloAsync(idClaseArticulo);
            nombresClaseArticuloObtenidos[idClaseArticulo] = nombreClaseArticulo;
            const elementoNombreClaseArticulo = elementosClaseArticulo[i];
            elementoNombreClaseArticulo.textContent = nombreClaseArticulo;
        }
    }
}



function validacion(nombres) {
    // Función que valida los datos ingresados por el usuario.
    const regex = /^[a-zA-Z\s.-]+$/; // Expresión regular para validar nombres
    const moneyRegex = /^\d+\.\d{2}$/; // Expresión regular para validar formato money
    var nombreEntrada = document.getElementById("variable1").value.trim();
    var precio = document.getElementById("variable2").value.trim();
    var resultado = JSON.parse(nombres.elements.resultados.value);//Variable que recibe nombres convertido a un obj de js
    if (nombreEntrada.trim() === "" || !regex.test(nombreEntrada.trim())) {
        //Valida que el nombre sea de solo letras
        alert(
            "El nombre está vacío o no contiene solo letras, puntos y comas."
        );
        return false;
    } else if (precio.trim() === "" || !moneyRegex.test(precio.trim())) {
        // Valida que 'precio' tenga formato money.
        alert("El precio está vacío o no es un número de dinero válido.");
        return false;
    }
    // Validar si el nombre ya existe en la lista de resultados
    if (resultado.find(r => r.nombre.toLowerCase() === nombreEntrada.toLowerCase())) {
        alert("El nombre ya existe en la lista de resultados. Por favor, elija otro.");
        return false;
    }
    return true; //retorna true si no hay errores
}