# frozen_string_literal: true

class LoginController < ApplicationController
  def index
    render "articulos/login"
  end

  def create
    puts "hola"
    redirect_to '/dashboard'
  end

  def destroy
    # Destruir la sesión del usuario
  end
end
