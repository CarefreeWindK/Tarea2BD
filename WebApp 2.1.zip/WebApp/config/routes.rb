Rails.application.routes.draw do
  root 'articulos#index'
  get 'articulo/index'
  get 'formulario', to: 'articulos#formulario'
  get 'application.css', to: 'application#css'
  post 'insertar', to: 'articulos#insertar'
  get '/formulario', to: 'articulos#nuevo'
  get 'articulo/idCLaseArticuloToNombreClaseArticulo/:id', to: 'articulos#idCLaseArticuloToNombreClaseArticulo'


  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
