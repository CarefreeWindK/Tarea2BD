//= link_tree ../images
//= link_directory ../stylesheets .css
//= link_tree ../../javascript .js
//= link_tree ../../../vendor/javascript .js


function insertar(){
    //funcion que abre otra pestana y permite ingresar articulos
    window.open('/formulario', 'MiVentana', 'width=500,height=223,resizable=0')
}
function cerrar() {
    //Funcion que cierra la webapp
    window.close();
}
function obtenerNombreClaseArticulo(id) {
    return fetch(`/articulo/idCLaseArticuloToNombreClaseArticulo/${id}`)
        .then(response => response.text())
        .then(palabra => {
            return palabra;
        })
        .catch(error => {
            console.error(`Error al obtener la palabra: ${error}`);
            // Hacer algo en caso de que se produzca un error, como mostrar un mensaje de error en la pantalla
        });
}

function validacion(nombres) {
    // Función que valida los datos ingresados por el usuario.
    const regex = /^[a-zA-Z\s.-]+$/; // Expresión regular para validar nombres
    const moneyRegex = /^\d+\.\d{2}$/; // Expresión regular para validar formato money
    var nombreEntrada = document.getElementById("variable1").value.trim();
    var precio = document.getElementById("variable2").value.trim();
    var resultado = JSON.parse(nombres.elements.resultados.value);//Variable que recibe nombres convertido a un obj de js
    if (nombreEntrada.trim() === "" || !regex.test(nombreEntrada.trim())) {
        //Valida que el nombre sea de solo letras
        alert(
            "El nombre está vacío o no contiene solo letras, puntos y comas."
        );
        return false;
    } else if (precio.trim() === "" || !moneyRegex.test(precio.trim())) {
        // Valida que 'precio' tenga formato money.
        alert("El precio está vacío o no es un número de dinero válido.");
        return false;
    }
    // Validar si el nombre ya existe en la lista de resultados
    if (resultado.find(r => r.nombre.toLowerCase() === nombreEntrada.toLowerCase())) {
        alert("El nombre ya existe en la lista de resultados. Por favor, elija otro.");
        return false;
    }
    return true; //retorna true si no hay errores
}
function nameToInt(){

}
