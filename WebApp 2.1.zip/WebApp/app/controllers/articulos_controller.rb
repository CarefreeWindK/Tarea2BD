class ArticulosController < ApplicationController
  def index
    @resultados = Articulo.buscarArticulos
    # procesar los resultados de la stored procedure y asignarlos a la vista
  end
  def formulario
    @resultados = Articulo.buscarArticulos
    # procesar los resultados de la stored procedure y asignarlos a la vista
  end
  def css
    # Configura la respuesta para que sirva el archivo CSS
    send_file "#{Rails.root}/app/assets/stylesheets/application.css", type: 'text/css', disposition: 'inline'
  end
  def insertar # Método que se ejecuta cuando se envía el formulario
    variable1 = params[:variable1] # Recupera el valor del parámetro 'variable1'
    variable2 = params[:variable2] # Recupera el valor del parámetro 'variable2'
    sql = "EXECUTE dbo.insertarArticulo
    #{ActiveRecord::Base.connection.quote(variable1)}
    ,#{ActiveRecord::Base.connection.quote(variable2)}" # Construye la sentencia SQL
    ActiveRecord::Base.connection.execute(sql) # Ejecuta la sentencia SQL
    # Envía un mensaje a todas las pestañas abiertas
    redirect_to formulario_path(allow_other_host: true), notice: 'Artículo insertado correctamente'
  end

  def nuevo
    # Aquí se puede agregar lógica para preparar los datos necesarios para el formulario
    render 'formulario' # Renderiza la vista 'nuevo.html.erb'
  end

  def idCLaseArticuloToNombreClaseArticulo
    id = params[:id].to_i
    palabra = ""

    # Ejecuta la sentencia SQL
    sql = "EXECUTE dbo.IdClaseArticuloToNombreClaseArticulo #{ActiveRecord::Base.connection.quote(id)}"
    ActiveRecord::Base.connection.execute(sql).each do |row|
      # Accede al valor devuelto por el stored procedure
      palabra = row['NombreClaseArticulo']
    end

    # Devuelve la palabra como cadena
    render plain: palabra
  end
  def NombreClaseArticuloToidCLaseArticulo
  end
end
