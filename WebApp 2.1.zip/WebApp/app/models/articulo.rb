class Articulo < ActiveRecord::Base
    def self.buscarArticulos
        self.table_name = 'Articulo'
        results = find_by_sql("EXEC dbo.buscarArticulos")
        if results.present?
            # procesar los resultados de la stored procedure
            return results
        else
            return []
        end
    end
end
