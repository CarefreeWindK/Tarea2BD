class CreateArticulos < ActiveRecord::Migration[7.0]

  #def self.insertarArticulo(nombre, precio)
  # results = find_by_sql("EXECUTE dbo.insertarArticulo ?, ?", [nombre, precio])
    # procesar los resultados de la stored procedure
    #return results
    #end

  def up
    # establecer la conexión a la base de datos de Azure
    connection = ActiveRecord::Base.connection
    sql = "EXECUTE [dbo].[buscarArticulos]"

    connection.execute(sql)
  end
end